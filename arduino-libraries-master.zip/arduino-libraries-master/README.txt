Snapshot of my Arduino libraries folder. I'd recommend you get the libraries
from the original sources, as these are not necessarily the most recent
versions. The projects in my other repos use these libraries, so I've put 
these here for completeness. 

Only Open Source licensed libraries are included.
