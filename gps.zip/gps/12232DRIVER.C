

#include <reg52.h>		//89C52 microcontroller header file
#include <LCD_code.h>		//LCD, liquid crystal font files
#include <intrins.h>		

//Pin function definitions

sbit A = P0^7;			//Data 1 / 0 Select command
sbit RW = P0^6;			//Read 1 / Write 0
sbit E1 = P0^4;			//Chip select 1(Master)
sbit E2 = P0^5;			//Chip select 2(slave)
sbit LED= P0^3;			//Backlight 
sbit up  = P0^0;		//Page Up key		 
sbit down= P0^1;		//Page Down key
#define data P2			//LCD parallel data


//Liquid crystal display control command table
#define disp_on 0xAf 		//Show  Close
#define disp_off 0xAe 		//Show  Open
#define disp_start_line 0xC0 	//Display start address (after the five - that 0-31 lines)
#define page_addr_set 0xB8 	//Page Address Set(0~3)
#define col_addr_set 0x00 	//Column Address Set(0~61)
#define status_busy 0x80 	//0 = ready
#define modeRWite 0xEE 		//Write mode
#define dynamic_driver 0xA4 	//Dynamic drive 
#define adc_select 0xA0		//clockwise
#define clk32 0xA9		//Refresh Clock Set 1/32
#define clk16 0xA8		//Refresh Clock Set 1/16
#define reset 0xE2 		//Software Reset

#define uchar unsigned char
#define uint unsigned int

//Global variables, and the definition of flag
uchar time_counter = 0;		//Software timer counter
uchar key = 0;			//Keyboard value
uchar serial_counter;		//Serial counter
	
bit disp_flag = 0;		//Show  Updates Logo
uchar bdata serial_byte = 0;	//Definition of serial port flag byte
sbit Sflag = serial_byte^0;	//Serial receiver head logo, about 8 are defined in'serial_byte'Within
sbit G1flag = serial_byte^1;
sbit Pflag = serial_byte^2;
sbit G2flag = serial_byte^3;
sbit G3flag = serial_byte^4;
sbit Aflag = serial_byte^5;
sbit DFflag = serial_byte^6;
sbit ENflag = serial_byte^7;
bit r_flag = 0;

unsigned char idata serial_buff[77];	//Serial Receive Buffer
//uchar code head[] = {'$','G','P','G','G','A',','};
//bit serial_flag = 0;	


////The main function LCD operation////////////////////////////////////////////////////////////
//void lcd_init(void)
//Quote:lcd_init(); Description: LCD initialization;
////////////////////////////////////////////////////////////////////////////////
//void lcd_clr(void)
//Quote:lcd_clr(); Description: LCD clear screen;
////////////////////////////////////////////////////////////////////////////////

void lcd_init(void); 		//LCD Initialization
void lcd_clr(void); 		//Clear LCD screen
void wait_ready(void); 		//Wait ready
void draw_bmp(uchar col,uchar layer,uchar width,uchar *bmp); //Dot matrix display output code
void ASCII2BCD(void);		//ASCII code is converted to BCD code	
void logo(void);		//Boot screen display

/*----------------------------------------------------------------------------
				Interrupt program
-----------------------------------------------------------------------------*/
////////////////////////////////////////////////////////////////////////////////
//Timer 0 interrupt function is used to control the backlight off delay 10S
///////////////////////////////////////////////////////////////////////////////
void int_t0() interrupt 1 using 1
{				//Timer 0 interrupt function is used to control the backlight off delay 10S
  TH0  = 0x4C;
  TL0  = 0x00;			//Reload Timer 0, Timer 50mS
  time_counter ++;		//Software counter +1;
  if (time_counter == 200)	//Software counter regularly to 10S, backlight off, the timer 0 counter clearing software
	{
	  time_counter = 0;
	  LED = 1;
	  TR0 = 0;
	 }
}

////////////////////////////////////////////////////////////////////////////////
//Serial port interrupt function for the statement &#39;$ GPGGA&#39; judgments and the reception of this statement
///////////////////////////////////////////////////////////////////////////////


void serial() interrupt 4 using 2
{
 uchar pp;
 RI=0;						
 pp=SBUF;
	if(ENflag==1)				//Serial port has been received, can be used to display, clear flag to start
	   {
	     disp_flag=1;
	     serial_byte = 0;   	
	    }
	else if(DFflag==1)			//'$GPGGA'Completion of the first judge,Start receiving$GPGGA,Statement data
	      {
               if(pp==42)			
                    ENflag=1;			//Waiting to receive'*'Receiving end
	       else  
	          {
	            serial_buff[serial_counter]=pp;	//Not received'*',Continue to receive the data into the serial port buffer
	            serial_counter++;	
	          }     	   
	      }	 
	else if(Aflag==1)			//The sixth is'A',The seventh judge is not','
	       {
	         if(pp==44)
	              DFflag=1;			//Seventh all is','Start receiving$GPGGA,Statement data
	         else 
	              serial_byte = 0;    	//Not',',Clear flag
	       } 
	else if(G3flag==1)			//The fifth is'G',Not to judge the sixth is'A'
	       {
	         if(pp==65)
	              Aflag=1;			//The sixth is'A'Not the next one is to judge','
	         else 
	              serial_byte = 0;    	//Not'A',Clear flag
	        } 
	else if(G2flag==1)			//The fourth is'G',The fifth judge is Not'G'
	        {
	          if(pp==71)
	               G3flag=1;		//The fifth is'G'Not the next one is to judge'A'
	          else 
	               serial_byte = 0;    	//Not'G',Clear flag
	              } 
	else if(Pflag==1)			//The third is'P',The fourth judge is Not'G'
	        {
	          if(pp==71)
	               G2flag=1;		//The fourth is'G'Not the next one is to judge'G'
	          else 
	               serial_byte = 0;    	//Not'G',Clear flag
	                   }
	else if(G1flag==1)			//The second is'G',The third judge is Not'P'
	         {
	           if(pp==80)
	                 Pflag=1;		//The third is'P'Not the next one is to judge'G'
	           else 
	                 serial_byte = 0;	//Not'P',Clear flag
	         } 
	 else if(Sflag==1)			//The first is'$',Not to judge the second is'G'
	         {
	           if(pp==71)
	                  G1flag=1;		//The second is'G'Not the next one is to judge'P'
	           else
	                  serial_byte = 0; 	//Not'G',Clear flag
	         }  
	 else if(pp==0x24)			//Not to judge the first one is$
	         {
		    Sflag=1;			//The first is$,The next judge is NotG
		    serial_counter=0;		//Serial counter cleared
	          } 
} 


/*

void serial() interrupt 4 using 2
{
  uchar i,buff;
  RI = 0;
  buff = SBUF;
  if(serial_flag == 1)
    {
      serial_buff[serial_counter] = buff;
      serial_counter ++;
      if(serial_counter > 37)
        {
          serial_flag = 0;
          serial_counter = 0;
	  for(i=0;i>7;i++)
            {
             if(head[i] == serial_buff[i])
               {
                 disp_flag = 1;
               }
             else
               {
                 disp_flag = 0;
                 i = 8;
               }
             
             }

        }

     }
  else
    {
      if(SBUF == '$')
        {
          serial_buff[0] = buff;
          serial_flag = 1;
          serial_counter ++;
        }
      else
        {
          serial_flag = 0;
          serial_counter = 0;
          
        } 
    }
}
*/


////////////////////////////////////////////////////////////////////////////////
//Call the method: void send_mi (uchar instuction)
//Function Description: Directive issued instruction to the main window (within the function, the private, the user can not directly call)
////////////////////////////////////////////////////////////////////////////////
void send_mi(uchar instruction)
{ 
E2 = 0; 		//Guan Slaver 
E1 = 1; 		//Open Master 
wait_ready();		//Determine busy
A = 0; 			//Instruction
RW = 0; 		//Was triggered 
data = instruction; 	//Script
E1 = 0; 		//Customs Master
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void OutMD(uchar i)
//Function Description: send data to the main window data (within the function, the private, the user can not directly call)
////////////////////////////////////////////////////////////////////////////////
void send_md(uchar c)
{
E2 = 0; 		//Guan Slaver
E1 = 1; 		//Open Master
wait_ready(); 		//Determine busy
A = 1; 			//Data
RW = 0; 		//Was triggered 
data = c; 		//Data
E1 = 0; 		//Customs Master
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void send_si(uchar instruction)
//Function Description: Directive issued instruction to the window (inside the function, the private, the user can not directly call)
////////////////////////////////////////////////////////////////////////////////
void send_si(uchar instruction)
{ 
E1 = 0; 		//Customs Master
E2 = 1; 		//Open Slaver
wait_ready(); 		//Determine busy
A = 0; 			//Instruction
RW = 0; 		//Was triggered 
data=instruction; 	//Script
E2 = 0; 		//Guan Slaver
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void send_sd(uchar data)
//Function Description: send data to the data from the window (inside the function, the private, the user does not directly call)
////////////////////////////////////////////////////////////////////////////////
void send_sd(uchar c)
{
E1 = 0;			//Customs Master
E2 = 1; 		//Open Slaver
wait_ready(); 		//Determine busy
A = 1; 			//Data
RW = 0; 		//Was triggered 
data = c;		//Data
E2 = 0;			//Guan Slaver
}

////////////////////////////////////////////////////////////////////////////////
//Wait for the ready: waiting for LCD to complete the internal operation, sub-busy
////////////////////////////////////////////////////////////////////////////////
void wait_ready(void)
{
A = 0;			//Instruction
RW = 1; 		//Reading
_nop_();		//Air operations to produce compilation inside nop
while(data & status_busy); //Read LCD status 1 = busy, been waiting for LCD to complete the internal operation
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void lcd_init(void)
//Function Description: 122x32LCD initialization call only once after boot
////////////////////////////////////////////////////////////////////////////////
void lcd_init(void)
{
send_mi(reset); 	//Reset m-left,s-right
send_si(reset);

send_mi(disp_off); 	//Close Show 
send_si(disp_off);

send_mi(dynamic_driver);//Dynamic drive
send_si(dynamic_driver);

send_mi(clk32); 	//1/32 duty cycle
send_si(clk32);

send_mi(adc_select); 	//clockwise
send_si(adc_select);

send_mi(modeRWite); 	//The end of write mode
send_si(modeRWite);

send_mi(col_addr_set);  //Return to zero out, the first set display start line
send_mi(disp_start_line); 
send_si(col_addr_set);
send_si(disp_start_line);

send_mi(disp_on); 	//Open Show 
send_si(disp_on); 
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void lcd_clr(void)
//Function Description: clear screen
////////////////////////////////////////////////////////////////////////////////
void lcd_clr(void)
{
uchar i, page;
for (page=0;page<4;page++)
  {
    send_mi(page_addr_set|page);//Settings page from the 0-3
    send_si(page_addr_set|page);
    send_mi(0); 	//The main window is set to 0
    send_si(0); 	//From the window set to 0 
    for (i=0;i<62;i++)  //All written 0x00
      {
        send_md(0x00);
        send_sd(0x00);
      }
  }
} 

////////////////////////////////////////////////////////////////////////////////
//Call the method: void set_page(uchar page)
//Function Description: Set the same time the main (right) from the (left) Show s the page for the 0-3 page
////////////////////////////////////////////////////////////////////////////////
void set_page(uchar page)
{
send_mi(page_addr_set|page);
send_si(page_addr_set|page);
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void SetAddress(uchar address)
//Function Description: Set the same time the main (right) from (left) column address is 0-61 column
////////////////////////////////////////////////////////////////////////////////
void set_address(uchar address)
{
send_mi(address&0x7F); //&0x7F,Taking into account the more restrictions to prevent
send_si(address&0x7F);
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void putchar_l(uchar c)
//Function Description: In the left page (main window) and draw the current address of a byte (8 points)
////////////////////////////////////////////////////////////////////////////////
void putchar_l(uchar c)
{
send_md(c);
}

////////////////////////////////////////////////////////////////////////////////
//Call the method: void putchar_r(uchar c)
//Function Description: In the right page (from the main window) to draw a current address byte (8 points)
////////////////////////////////////////////////////////////////////////////////
void putchar_r(uchar c)
{
send_sd(c);
} 

////////////////////////////////////////////////////////////////////////////////
//Call the method: void draw_bmp(uchar col,uchar layer,uchar width,uchar *bmp)
//Function Description: Draw a diagram, the abscissa is the col, layer, said upper and lower layers, width is the width of the graphic, high fixed 16
// bmp is a graphic pointer
// Use Zimo3Pro software, using the longitudinal modulus, get data byte reverse.
// col graphics starting position of the 0 ~ 121
// layer graphics position (Y coordinates) 0 - upper half of non-0 - second half
// width Graphic width 8,16 Optional
// bmp Graphic data pointer
////////////////////////////////////////////////////////////////////////////////
void draw_bmp(uchar col,uchar layer,uchar width,uchar *bmp)
{
uchar x; 
uchar address; 			//that the physical address of memory address
uchar p=0; 
uchar page=0;
uchar window=0; 		//said upper and lower page 2, window around that window (0 left, 1 right)
if (layer) page=2; 		//Left - the main window, right - from the window

for (x=col; x<col+width; x++)
{ 
  if (x>121)return; 		//To prevent garbled
  if (x>60) 			//About window positioning
    {
      window=1; 			//Right - from the window
      address=x%61;
    }
  else
  {
    address=x;
  } 			//Output main window 

  set_page(page); 		//Upper data output
  set_address(address);

  if (window) 
    {
      putchar_r(bmp[p]); 
    }
  else
  {
    putchar_l(bmp[p]);
  } 

  set_page(page+1); 		//Lower data output
  set_address(address); 		//Column remains the same 

  if (window) 
     {
       putchar_r(bmp[p+width]); 
     }
  else
    {
      putchar_l(bmp[p+width]); 
     }
  p++;
  }
}




/*------------------------------------------------------------------------------
                  Delayed procedures: entry unsinged char i, i ms delay
-------------------------------------------------------------------------------*/            

delay(uchar i) 
{
  uchar j;
  for(i=i<<1;i>0;i--)
  for(j=0xf3;j>0;j--)
  {}
}

//////////////////////////////////////////////////////////////////////////////
//Keyboard scanner, a key is pressed, modify key values
//////////////////////////////////////////////////////////////////////////////
keywork(void)
{ 
  if(!(up&&down))	//Whether the key is pressed
  {
     delay(20);		//Delay 5MS
     if(up&&down)	//Key is pressed again to judge whether there is no return
     {
       return;
      }
     if(!up)		//Check up key
       {
         while(!up);	//Wait up key release
         key ++;	//key value plus 1
         LED = 0;	//Bright backlight
         TR0 = 1;	//Open Timer 0, back light 10S
         time_counter = 0;//Clear timer software counter, after the light from the backlight button 10S
         if (key == 3)	//key value of super-maximum limit set
           {
             key = 0;
           }
         return;   
        }
     if(!down)		//Charlie down keys
       {
         while(!down);	//Wait for the down key to release
         key --;	//key value by 1
         LED = 0;	//Bright backlight
         TR0 = 1;	//Open Timer 0, back light 10S
         time_counter = 0;//Clear timer software counter, after the light from the backlight button 10S
         if (key ==255)
           {
            key = 2;	////key value of super-maximum limit set
           }
         return;
        }
    }
  
  
}

disp_transit()
{
  uchar j, row = 0 ,temp;
  temp = (serial_buff[25]*10+serial_buff[26])*3/5;	//Longitude final. XX-point conversion bit seconds
  serial_buff[25] = temp/10;
  serial_buff[26] = temp%10; 
  temp = (serial_buff[12]*10+serial_buff[13])*3/5;	//Latitude final. XX minutes into seconds
  serial_buff[12] = temp/10;
  serial_buff[13] = temp%10;
  lcd_clr();					//Qing Ping
  draw_bmp(0,0,16,azimuth[serial_buff[30]-20]); //To judge the East, West, and display
  draw_bmp(16,0,16,jing);                       //Show 'After'
  draw_bmp(32,0,8,num[13]); 			//Show ':'
  for(j = 19;j<28;j++)				//Show  longitude
    {
     if (j == 22)
       {
         draw_bmp(40+row*8,0,8,num[11]); 	//Show  digital degree symbol
         row++;
       }
     if (j == 24)
       {
         draw_bmp(40+row*8,0,8,num[12]); 	//Show '''(Point)
         row++;
         j++;
       }

     if (j == 27)				//Show '"'(Second)
       {
         draw_bmp(40+row*8,0,8,num[14]); 
         row++;
         break;
       }
     draw_bmp(40+row*8,0,8,num[serial_buff[j]]); //Show Figure
     row++;

    }
  
  
  row = 0;
  draw_bmp(0,1,16,azimuth[serial_buff[17]-20]);  //To judge the south and north,��Show 
  draw_bmp(16,1,16,wei);			 //Show  Latitude
  draw_bmp(32,1,8,num[13]);			 //Show :
  for(j = 7;j<15;j++)
    {
     
     if (j==9)					//Show  Word degree symbol
       {
         draw_bmp(40+row*8,1,8,num[11]); 
         row++;
       }
     if (j==11)
       {
         draw_bmp(40+row*8,1,8,num[12]); 	//Show '''(Point)
         row++;
         j++;
         
       }
     if (j==14)					//Show '"'(Second)
       {
         draw_bmp(40+row*8,1,8,num[14]); 
         row++;
         break;
       }
     draw_bmp(40+row*8,1,8,num[serial_buff[j]]); //Show  Figure
     row++;
     
    }                      
   

}


disp_time()
{
  uchar hour, j, row = 0;	
  lcd_clr();			//Qing Ping
  draw_bmp(29,0,64,bjsj);	//Top 29 start in Show LCD 'Beijing'
  hour = serial_buff[0]*10+serial_buff[1]+8;	//GMT into Beijing
  if (hour>23)					//Beijing Time = GMT +8
  {hour = hour - 24;}				//When more than 24 hours, minus 24
  serial_buff[0] = hour/10;			//Restore to the buffer
  serial_buff[1] = hour%10;
  for( j=0;j<6;j++ )				//Show  6 figures and 2 colon, the format XX: XX: XX
   {
     draw_bmp(29+row*8,1,8,num[serial_buff[j]]); //Show 6 digits
     row++;
     if ((j==1)||(j==3))			//2nd and 4th digits behind the Show ':'
       {
         draw_bmp(29+row*8,1,8,num[13]); 	//Show Colon
         row++;
       }
   }
  
}

disp_level()
{
 uchar i,j,row = 1;
 lcd_clr();
 draw_bmp(0,0,120,level);
 if(serial_buff[32] == 0)  //No GPS signal reception
   {
     draw_bmp(0,1,112,nosignal);
   }
 else
   {			//Detect the location of the level of signal data stored
     for (i=35;row;)
       {
         if (serial_buff[i] == 'M')
           {
             i = i+2;
             row = 0;	//Out of circulation
           }
         else
           {
            i++;
           }
       }
     j = i;
     row = 1;
     for (;row;)
       {
        if (serial_buff[j] == 'M')
           {
             row = 0;	//Out of circulation
           }
         else
           {
            j++;
           }
       } 
       
     for (;i<j-1;i++)
       {
         draw_bmp(0+row*8,1,8,num[serial_buff[i]]);
         row ++;
       }
    draw_bmp(0+row*8,1,8,num[15]);
   }
 
}


disp_speed()					//Speed Show program
{

}

disp_direction()				//Show the direction of program
{

}
/*-----------------------------------------------------------------------
		Show program, according to Show keyboard call different function values
-------------------------------------------------------------------------*/


display()
{
 ASCII2BCD ();			//First call to ASCII conversion functions convert BCD to ASCII
 
 switch (key)
   {				//According to Show keyboard call different function values
     case 0 : { disp_transit();  break;} 	//Keyboard value 0, Show latitude and longitude
     case 1 : { disp_time();     break;}	//Keyboard value 1, Show Beijing
     case 2 : { disp_level();    break;}
     case 3 : { disp_speed();    break;}	//Keyboard value 3, Show Speed
     case 4 : { disp_direction();break;}	//Keyboard value 4, Show Direction
     default: { disp_transit();  break;}
     						//Scalable
   }

}


/*-----------------------------------------------------------------------
		Will receive the ASCII conversion bit BCD code and the specific values
------------------------------------------------------------------------*/

void ASCII2BCD(void)
{			
  uchar i;
  for (i=0;i<60;i++)		//Only 38 before converting the data received
    {
      if ((serial_buff[i] >= 48) && (serial_buff[i] <= 57) )  
        {			//Received a number, converted to BCD code. BCD code = ASCII code -48
          serial_buff[i] = serial_buff[i]-48 ;
        }
      else
        {
          switch ( serial_buff[i] )
 		       {	//Non-numeric, convert them to a specific value
 			case '.' : { serial_buff[i] = 10; break; }
 			
 			case '-' : { serial_buff[i] = 16; break; }
 			 			
 			case 'E' : { serial_buff[i] = 20; break; }
			case 'S' : { serial_buff[i] = 21; break; }
			case 'W' : { serial_buff[i] = 22; break; }
			case 'N' : { serial_buff[i] = 23; break; }
			case ',' : { serial_buff[i] = 0xff;break;}
			default : break;
		       }
        }
    }
}
/*-------------------------------------------------------------------------
                   LOGO boot screen, boot time is called
---------------------------------------------------------------------------*/

void logo(void)
{                                
  uchar i, j, h ;
  LED = 0;                       //Lit backlight
  TR0 = 1;                       //Open Timer 0, backlight lights 10S
  lcd_clr();
  draw_bmp(0,0,112,welcome_1);  //In the upper section 0 beginning LCD Show ��Welcome to GPS��
  draw_bmp(32,1,48,welcome_2);  //The lower part of the first 32 in the LCD started Show Show ��System��
  for(i=0;i<10;i++)for(j=1;j;j++)for(h=1;h;h++);  //Delay 3S
  lcd_clr();                    //clear
  draw_bmp(0,0,64,welcome_3);   //LCD upper section 0 beginning Show &#39;designer:&#39;
  draw_bmp(64,1,48,welcome_4);  //The lower part of the first 64 in the LCD start Show &#39;Tang Zhao Bo&#39;
  for(i=0;i<5;i++)for(j=1;j;j++)for(h=1;h;h++);  //Delay 1.5S
  
}


////////////////////////////////////////////////////////////////////////////////
//				Main program
////////////////////////////////////////////////////////////////////////////////
void main(void)
{ 
  P0   = 0xff;                  //Port Reset
  P1   = 0xff;
  P2   = 0xff;
  P3   = 0xff;
  delay(255);   
  lcd_init();                   //Liquid crystal device initialization Show
  lcd_init();
  lcd_init();
  lcd_clr();			//clr
  logo();			//Show Boot screen

//TMOD: GATE|C/!T|M1|M0|GATE|C/!T|M1|M0
//        0    0   1  0   0    0   0  1
  TMOD = 0x21;			//T0 16-bit timer, T1 automatic reload, mode 3
  TH0  = 0x4C;
  TL0  = 0x00;			//Time 50mS
//SCON: SM0|SM1|SM2|REN|TB8|RB8|TI|RI
//        0   1   0   0   0   0  0  0
  SCON = 0x40;			//Serial port 8-bit UTRA
  TH1  = 0xFA;
  TL1  = 0xFA;			//Baud Rate Generator,4800bps
  ET0  = 1;			//Timer 0 interrupt to allow open
  ES   = 1;			//Open the serial port interrupt
  EA   = 1;			//Open general interrupt
  REN  = 1;			//Allow serial receiver
  TR1  = 1; 			//Open the serial port baud rate occurred(T1)
  while(1) 			//Main program
    {
     up = 1;			//The location of a keyboard for typing
     down = 1;
     keywork();			//Keyboard scan
     if(disp_flag)		//Determine whether to update the Show 
       {
         disp_flag = 0;		//Show Updates clear signs
         display();		//Show Program
       }

     }
}


